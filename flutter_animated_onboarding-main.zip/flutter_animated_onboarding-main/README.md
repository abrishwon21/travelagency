
# 🔥🔥 Flutter Animated Onboarding And Login Page

Flutter project for creating animated onboarding and login screen.

Star⭐ the repo if you like what you like more stuff on flutter 😉.

## ✨ Requirements
* Any Operating System (ie. MacOS X, Linux, Windows)
* Any IDE with Flutter SDK installed (ie. IntelliJ, Android Studio, VSCode etc)
* A little knowledge of Dart and Flutter.

## Some Screenshots For You 💖

<img height="600" width="300" src="screenshots/ss1.png">|
<img height="600" width="300" src="screenshots/ss2.png">  
<img height="600" width="300" src="screenshots/ss3.png">|
<img height="600" width="300" src="screenshots/ss4.png">

 

## 🤓 Author(s)
**Manish Dayma** [![Twitter Follow](https://img.shields.io/twitter/follow/manishdayma22.svg?style=social)](https://twitter.com/manishdayma22)
