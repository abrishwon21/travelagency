package com.animated.onboarding.flutter_animated_onboarding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
